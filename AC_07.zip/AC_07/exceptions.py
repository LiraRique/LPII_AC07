class VacinaGato(Exception):
    