from vacinas import vacina,cat,Dog,horse

def test_cat():
    c =cat('Vacina intra muscular')
    assert c.vacina_certa()== 'Vacina intra muscular'

def test_dog():
    d= Dog('Vacina intra venosa')
    assert d.vacina_certa() == 'Vacina intra venosa'

def test_horse():
    h= horse('Vacina de superficie')
    assert h.vacina_certa() == 'Vacina de superficie' 




