class animal():
    def __init__(self,tipo_vacina):
        self.tipo_vacina = tipo_vacina

class cat(animal):
    def __init__(self,tipo_vacina):
        if tipo_vacina != 'Vacina intra muscular':
            raise Exception('Vacina do tipo errada!!!')

    def vacina_certa(self):
        return 'Vacina intra muscular'

    def Vacinar(self):
        if tipo_vacina != 'Vacina intra muscular':
            vacina.__init__(self,tipo_vacina)

class Dog(animal):
    def __init__(self,tipo_vacina):
        if tipo_vacina == 'Vacina intra venosa':
            vacina.__init__(self,tipo_vacina)
        else:
            raise Exception('Vacina do tipo errada!!!')
    
    def vacina_certa(self):
        return 'Vacina intra venosa'

class horse(animal):
    def __init__(self,tipo_vacina):
        if tipo_vacina == 'Vacina de superficie':
            vacina.__init__(self,tipo_vacina)
        else:
            raise Exception('Vacina do tipo errada!!!')

    def vacina_certa(self):
        return 'Vacina de superficie'